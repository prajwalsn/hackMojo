from flask import Flask, render_template , flash , redirect , url_for , session ,request, logging
from flask_mysqldb import MySQL
from wtforms import Form, StringField , TextAreaField ,IntegerField, PasswordField, validators
from passlib.hash import sha256_crypt
from functools import wraps
import logging
import datetime

app = Flask(__name__)

#Config Mysql
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'flix'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

#initialize mysql
mysql = MySQL(app)




@app.route('/')
def index():
    return render_template('home.html')


@app.route('/about')
def about():
    return render_template('about.html')


class RegisterForm(Form):
    email = StringField('Email', [validators.Length(min=6 , max = 50)])
    typeid = IntegerField('TypeId')
    password = PasswordField('Password',[
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passswords do not match')
    ])
    confirm = PasswordField('Confirm Password')

@app.route('/register' , methods = ['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method =='POST' and form.validate():
        email = form.email.data
        password = sha256_crypt.encrypt(str(form.password.data))
        typeid = form.typeid.data

        #Create Cursor
        cur = mysql.connection.cursor()

        cur.execute("INSERT INTO USER(email,password) VALUES(%s,%s)", (email, password))

        #Commit to DB
        mysql.connection.commit()

        #close connection
        cur.close()

        flash('You are now registered and can log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method =="POST":
        #Get Form Fields
        email = request.form['email']
        password_candidate = request.form['password']

        #create a cursor 
        cur = mysql.connection.cursor()

        #Get use by username 
        result = cur.execute("SELECT * FROM USER WHERE email = %s" , [email])

        if result > 0:
            #get stored hash
            data = cur.fetchone()
            password = data['password']

            #Compare the passwords 
            if sha256_crypt.verify(password_candidate,password):
                #Passed
                session['logged_in'] = True
                session['email'] = email

                flash("You are now logged in", 'success')
                return redirect(url_for('dashboard'))
            else:
                error = "Invalid password"
                return render_template('login.html',error=error)
            #Close connection    
            cur.close()
        else:
            error = "Username not found"
            return render_template('login.html',error=error)
    return render_template('login.html')

#Check if use is logged in 
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args,**kwargs)
        else:
            flash("Unauthorizaed please log in ", 'danger')
            return redirect(url_for('login'))
    return wrap

#Logout
@app.route('/logout')
def logout():
    session.clear()
    flash('You are now logged out', 'success')
    return redirect(url_for('login'))


#Dashboard
@app.route('/dashboard', methods=["GET", "POST"])
@is_logged_in
def dashboard():

    cur = mysql.connection.cursor()

    result = cur.execute('select * from video');

    if result > 0:
        data = cur.fetchall()

        cur.close() 
    else:
        logging.info("Error in video fetch")

    return render_template('dashboard.html', data=data)

@app.route('/subscribe',methods=["GET","POST"])
def subscribe():
    if request.method =="POST":
        email = session['email']
        start_date = datetime.datetime.now()
        video_id = request.form['ButtonSelect']
    return render_template('home.html')

if __name__ == '__main__':
    app.secret_key='secret123'
    app.run(debug=True)